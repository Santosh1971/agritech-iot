%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-10-10T11:57:22+05:30*%
%TF.ProjectId,ASC-AHT20,4153432d-4148-4543-9230-2e6b69636164,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-10-10 11:57:22*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
%ADD12RoundRect,0.250000X-0.250000X-0.475000X0.250000X-0.475000X0.250000X0.475000X-0.250000X0.475000X0*%
%ADD13RoundRect,0.075000X-0.375000X-0.175000X0.375000X-0.175000X0.375000X0.175000X-0.375000X0.175000X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X102590000Y-63000000D03*
D11*
X105130000Y-63000000D03*
X107670000Y-63000000D03*
X110210000Y-63000000D03*
%TD*%
D12*
%TO.C,C1*%
X139650000Y-63000000D03*
X141550000Y-63000000D03*
%TD*%
D13*
%TO.C,U1*%
X143950000Y-62000000D03*
X143950000Y-63000000D03*
X143950000Y-64000000D03*
X146050000Y-64000000D03*
X146050000Y-63000000D03*
X146050000Y-62000000D03*
%TD*%
M02*
